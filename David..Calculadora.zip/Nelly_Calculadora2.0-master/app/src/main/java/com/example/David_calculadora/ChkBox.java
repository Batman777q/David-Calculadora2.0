package com.example.David_calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ChkBox extends AppCompatActivity {
    EditText _txtNum1, _txtNum2;
    TextView _tvResult;
    CheckBox _chkSuma, _chkResta, _chkMultiplicacion, _chkDivision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_check_box);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        _txtNum1 = findViewById(R.id.txtNum1_chk);
        _txtNum2 = findViewById(R.id.txtNum2_chk);
        _tvResult = findViewById(R.id.tvResultado_Cb);
        _chkSuma = findViewById(R.id.cbSumar);
        _chkResta = findViewById(R.id.cbResta);
        _chkMultiplicacion = findViewById(R.id.cbMultiplicacion);
        _chkDivision = findViewById(R.id.cbDivision);
    }

    private float Validar(String num){
        if (num.equals(" ")) {
            return 0;
        }else{
            return Float.parseFloat(num);
        }
    }

    public void CalcularChk(View calcular){
        String n1 = _txtNum1.getText().toString();
        String n2 = _txtNum2.getText().toString();

        float num1 = Validar(n1);
        float num2 = Validar(n2);
        String resultado= "";

        if(_chkSuma.isChecked()){
            float suma = num1 + num2;
            resultado+= "Resultado: "+suma+"\n";
        }
        if(_chkResta.isChecked()){
            float resta = num1 - num2;
            resultado+= "Diferencia: "+resta+"\n";
        }
        if(_chkMultiplicacion.isChecked()){
            float multiplicacion = num1 * num2;
            resultado+= "Productos: "+multiplicacion+"\n";
        }
        if(_chkDivision.isChecked()) {
            if (num2 == 0) {
                Toast.makeText(this, "El segundo número no puede ser 0",Toast.LENGTH_SHORT).show();
            } else {
                float division = num1 / num2;
                resultado += "Cociente: " + division + "\n";
            }
        }
        _tvResult.setText(resultado);
    }
}
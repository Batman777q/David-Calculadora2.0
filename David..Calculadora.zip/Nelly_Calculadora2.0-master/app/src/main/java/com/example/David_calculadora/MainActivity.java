package com.example.David_calculadora;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button _btnRdo;
    Button _btnChk;
    Button _btnTbl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        _btnRdo = findViewById(R.id.btn_rdo);
        _btnChk = findViewById(R.id.btn_chk);
        _btnTbl = findViewById(R.id.btn_tbl);

        _btnRdo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent rdoBtn = new Intent(MainActivity.this,RadioBtn.class);
                startActivity(rdoBtn);
            }
        });

        _btnChk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chkBtn = new Intent(MainActivity.this, ChkBox.class);
                startActivity(chkBtn);
            }
        });

        _btnTbl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tblBtn = new Intent(MainActivity.this, Table.class);
                startActivity(tblBtn);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
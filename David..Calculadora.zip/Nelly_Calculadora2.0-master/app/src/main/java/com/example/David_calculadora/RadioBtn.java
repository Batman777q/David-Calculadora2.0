package com.example.David_calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RadioBtn extends AppCompatActivity {
    EditText _txtNum1, _txtNum2;
    TextView _tvResult;
    RadioButton _rdoSuma, _rdoResta, _rdoMultiplicacion, _rdoDivision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_radio_btn);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        _txtNum1 = findViewById(R.id.txtNum1_rdo);
        _txtNum2 = findViewById(R.id.txtNum2_rdo);
        _tvResult = findViewById(R.id.tvResult_rdo);
        _rdoSuma = findViewById(R.id.rdoSuma);
        _rdoResta = findViewById(R.id.rdoResta);
        _rdoMultiplicacion = findViewById(R.id.rdoMultiplicacion);
        _rdoDivision = findViewById(R.id.rdoDivision);
    }

    private float Validar(String num){
        if (num.equals("")) {
            return 0;
        }else{
            return Float.parseFloat(num);
        }
    }

    public void CalcularRdo(View calcular){
        String n1 = _txtNum1.getText().toString();
        String n2 = _txtNum2.getText().toString();

        float num1 = Validar(n1);
        float num2 = Validar(n2);
        String resultado= "";

        if(_rdoSuma.isChecked()){
            float suma = num1 + num2;
            resultado+= "Resultado: "+suma+"\n";
        }
        if(_rdoResta.isChecked()){
            float resta = num1 - num2;
            resultado+= "Diferencia: "+resta+"\n";
        }
        if(_rdoMultiplicacion.isChecked()){
            float multiplicacion = num1 * num2;
            resultado+= "Producto: "+multiplicacion+"\n";
        }
        if(_rdoDivision.isChecked()) {
            if (num2 == 0) {
                Toast.makeText(this, "El segundo numero no puede ser 0",Toast.LENGTH_SHORT).show();
            } else {
                float division = num1 / num2;
                resultado += "Cociente: " + division + "\n";
            }
        }
        _tvResult.setText(resultado);
    }
}